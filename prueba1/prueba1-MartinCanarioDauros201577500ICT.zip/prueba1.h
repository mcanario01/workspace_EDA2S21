#include "prueba1Struct.h"
#include "TDA-Lista-v2/lista.h"

//RESPUESTA b - 1
void caniSort(Lista &lista, Lista &lista_ordenada, int cuenta);

//RESPUESTA b - 2

void imprimirCuartoRegistro(char* arch);
