#include <stdio.h>
#include "prueba1.h"

void caniSort(Lista &lista, Lista &lista_ordenada, int cuenta);

void imprimirCuartoRegistro(char* arch);

int main(){
    imprimirCuartoRegistro("clientes.txt");
    return 0;
}

