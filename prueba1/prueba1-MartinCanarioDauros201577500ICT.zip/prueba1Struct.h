#ifndef PRUEBA1_STRUCT_H
#define PRUEBA1_STRUCT_H

//RESPUESTA b - 1

struct Cliente
{
    char nombre[100];
    unsigned int rut;
};


#endif